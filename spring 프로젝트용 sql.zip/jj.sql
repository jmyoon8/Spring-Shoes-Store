--��������--------------------------------------
CREATE USER jj IDENTIFIED BY jj DEFAULT TABLESPACE USERS;
grant connect, RESOURCE TO jj;
grant create view to jj;
ALTER USER jj ACCOUNT UNLOCK;



--ȸ�����̺�------------------------------------------------
DROP TABLE member CASCADE CONSTRAINTS;
CREATE TABLE member(
memId VARCHAR2(10) CONSTRAINT member_memId_pk PRIMARY KEY,
memPwd VARCHAR2(10) CONSTRAINT member_memPwd_nn NOT NULL,
address1 VARCHAR2(100) CONSTRAINT member_address1_nn NOT NULL,
address2 VARCHAR2(100) CONSTRAINT member_address2_nn NOT NULL,
address3 VARCHAR2(100) CONSTRAINT member_address3_nn NOT NULL,
name    VARCHAR2(50) CONSTRAINT member_name_nn  NOT NULL,
jumin1  VARCHAR2(10) CONSTRAINT member_jumin1_nn NOT NULL,
jumin2  VARCHAR2(10) CONSTRAINT member_jumin2_nn NOT NULL,
hp      VARCHAR2(20) CONSTRAINT member_hp_nn    NOT NULL,
email   VARCHAR2(40) CONSTRAINT member_email_nn NOT NULL,
reg_date TIMESTAMP(9) default sysdate,
authority  VARCHAR2(40)  default 'ROLE_MEMBER',
enabled NUMBER(1) default 1
);
ALTER TABLE member
ADD enabled NUMBER(1) default 1;
ALTER TABLE member
ADD authority VARCHAR2(40)  default 'ROLE_MEMBER';
UPDATE member
SET authority='ROLE_MEMBER';
UPDATE member
set enabled=1;
commit;
UPDATE member
set memPwd='$2a$10$QifhseTQ5l0J9HXZSW2oHumZzl0YbJFMY4tndFunmZZOUI.eq5soW';

INSERT INTO member
(memId,memPwd,address1,address2,address3,name,jumin1,jumin2,hp,email,reg_date,authority,enabled)
VALUES('host','manager','1','1','1','name','111','111','111','jmyoon8@naver.com',sysdate,'manager',1);
update member
set memPwd='$2a$10$QlrpX5wUStJ..fHSAC0heejVGm2d/Ii0GG3mmeV8l2BpC6lErz.Gq'
where memId='host';
commit;

UPDATE MEMBER
SET authority='ROLE_MANAGER'
WHERE memId='host';

UPDATE MEMBER
SET authority='ROLE_MEMBER'
WHERE memId='jmyoon8';
commit;
--������-----------------------------------------
DROP TABLE manager CASCADE CONSTRAINTS;
CREATE TABLE manager(
hostId VARCHAR2(10) primary key,
hostPwd VARCHAR2(10) not null
);


--�Խ���---------------------------------------------
CREATE TABLE board(
num NUMBER PRIMARY KEY,
writer VARCHAR2(40) NOT NULL,
subject VARCHAR2(50) NOT NULL,
contents VARCHAR2(4000),
cnt NUMBER default 0,
ref NUMBER default 0,
ref_step NUMBER default 0,
ref_level NUMBER default 0,
reg_date TIMESTAMP default sysdate,
news VARCHAR2(20) default 'post'
);
--�Խ��� ������
DROP SEQUENCE board_seq;
CREATE SEQUENCE board_seq
START WITH 1
INCREMENT BY 1
MAXVALUE 99999;

-----------�������� �Ѹ���---
select * from board where news='news' order by num desc;

--�˻���+���� �۾��� �۳��� ���հ˻�
SELECT * FROM (SELECT num, writer, subject, contents, cnt, ref, ref_step, ref_level, reg_date, news, rowNum rNum
					FROM (SELECT * FROM board WHERE news ='post' and (subject LIKE '%%' or writer LIKE '%%')  ORDER BY ref desc, ref_step asc))
                    where rNum >= 1 AND rNum <=5;                               --��ȣ �ļ� �ϰ�ó��!!! �̰Ͷ����� 1�ð� ���ȴ� !
--��������ȣ ��������--�������� ��������--�Խ��� �ѷ��� sql��

--�˻�+�Խñ� �Ѽ�
SELECT count(*) FROM (SELECT num, writer, subject, contents, cnt, ref, ref_step, ref_level, reg_date, news, rowNum rNum
FROM (SELECT * FROM board WHERE news ='post' and (subject LIKE '%%' or writer LIKE '%%')  ORDER BY ref desc, ref_step asc));
                    
                    

                    



                     



------------------����------------------------------------------------------------
DROP TABLE stock cascade CONSTRAINTS;
CREATE TABLE stock(
shoesNumber NUMBER(15) PRIMARY KEY,
pic VARCHAR2(100) NOT NULL,
brand varchar2(50) not null,
modelName varchar2(50) not null,
price NUMBER not null,
stockCount NUMBER not null check(stockcount>=0),
category VARCHAR2(30) not NULL,
cnt number(20) DEFAULT 0,
reg_date TIMESTAMP DEFAULT sysdate
);
select *from stock;

ALTER TABLE stock
drop COLUMN category;



--��� ������
DROP SEQUENCE stock_seq;
CREATE SEQUENCE stock_seq
START WITH 1
INCREMENT BY 1;
--��� ��ä ����
SELECT count(*) total FROM stock;
--����Խù��� �ѷ��� sql��
select*from
(select shoesNumber,pic, brand, modelName, price, stockCount,category,reg_date, rowNum rNum from(select*from stock order by reg_date))
where rNum >=1 and rNum<=2;



--īƮ-------------------------------
DROP TABLE cart;
CREATE TABLE CART(
cNum        NUMBER(10) PRIMARY KEY,
memId       REFERENCES MEMBER(memId)on DELETE CASCADE,
shoesNumber REFERENCES STOCK(shoesNumber)on DELETE CASCADE,
cCount      NUMBER(10) NOT NULL CHECK(cCount>=0),
confirm     VARCHAR2(30)
);
--īƮ������-----------------------
DROP SEQUENCE cart_seq;
CREATE SEQUENCE cart_seq
START WITH 1
INCREMENT BY 1;
select *from cart;
--īƮ ��� �Ѹ���------------------------
select *
from cart c, stock s
where c.shoesNumber = s.shoesNumber
AND c.memId='qweqwe';
-----------īƮ ���� ������-----------
SET SERVEROUTPUT ON
CREATE OR REPLACE PROCEDURE confirmcart(
v_cNum IN CART.CNUM%type
)
is
v_memId cart.memId%type;
v_shoesNumber cart.shoesNumber%type;
v_oCount orderlist.oCount%type;
BEGIN
select MEMID        into v_memId        from cart where CNUM= v_cNum;
select SHOESNUMBER  into v_shoesNumber  from cart where CNUM= v_cNum;
select CCOUNT       into v_oCount       from cart where CNUM= v_cNum;
update cart
set confirm ='�ֹ�Ȯ��'
where cNum=v_cNum;
INSERT INTO ORDERLIST
(ONUM,MEMID,SHOESNUMBER,OCOUNT)
VALUES(ORDER_NUM.nextval, v_memId, v_shoesNumber, v_oCount);
delete cart
where confirm='�ֹ�Ȯ��';
commit;
END;
/
execute confirmcart(63);
-----------��������Ʈ----------------------------
DROP TABLE orderList cascade CONSTRAINTS;
CREATE TABLE orderList(
oNum NUMBER(10) primary key,
memId REFERENCES member(memId)on DELETE CASCADE,
shoesNumber VARCHAR2(20) NOT NULL,
oCount NUMBER(10) not null check(oCount>=0)
);
---���� ������
DROP SEQUENCE order_num;
CREATE SEQUENCE order_num
Start with 1
INCREMENT BY 1;
---���� �Խù� sql��-----
SELECT *  FROM
(select  oNum ,brand,memId,price,pic,modelName,oCount,shoesNumber, rowNum rNum from
--���ʿ� ��ȣ�ȿ� �÷��� �������־�� ��ȣ ���ʿ� �÷��� �ҷ��ö� �ް����� �ʰ� �ٷ� �ҷ��´�(�÷����� !!)
(select  o.oNum ,o.memId,s.price,s.pic,s.modelName,s.brand,o.oCount,s.shoesNumber
from orderList o, stock s where o.shoesNumber=s.shoesNumber order by oNum desc))
where rNum >=1 and rNum<=2;


---------ȯ��/��Ż ���̺�----------
DROP TABLE refund_And_total cascade CONSTRAINTS;

create Table refund_And_total(
pNum NUMBER(10) primary key,
Onum NUMBER(10) NOT NULL,
memId VARCHAR2(20) NOT NULL,
shoesNumber NUMBER(10) NOT NULL,
pCount number not null check(pCount>=0),
dNum number DEFAULT 1,
reg_date TIMESTAMP DEFAULT sysdate
);
---ȯ�� ��Ż ���̺�--
--��� sql 
select sum(s.price*r.pcount) total
     , substr(TRUNC(r.reg_date),1,5) month
    FROM stock s, refund_And_total r
    where s.shoesNumber=r.shoesNumber
    AND r.reg_date>='2020-0101' AND r.reg_date<='2020-1231'
    GROUP BY substr(TRUNC(r.reg_date),1,5)
    ORDER BY SUBSTR(TRUNC(r.reg_date),1,5);
--�Ѹ���
select sum(s.price*r.pcount) total
 , substr(TRUNC(r.reg_date),1,2) month
FROM stock s, refund_And_total r
where s.shoesNumber=r.shoesNumber
AND r.reg_date>='2020-0101' AND r.reg_date<='2020-1231'
GROUP BY substr(TRUNC(r.reg_date),1,2)
ORDER BY SUBSTR(TRUNC(r.reg_date),1,2);
--��ո���
select ROUND(avg(s.price*r.pcount),0) avg
 , substr(TRUNC(r.reg_date),1,2) month
FROM stock s, refund_And_total r
where s.shoesNumber=r.shoesNumber
AND r.reg_date>='2020-0101' AND r.reg_date<='2020-1231'
GROUP BY substr(TRUNC(r.reg_date),1,2)
ORDER BY SUBSTR(TRUNC(r.reg_date),1,2);

SELECT*
FROM REFUND_AND_TOTAL r, stock s
WHERE r.shoesNumber=s.shoesNumber
AND memId = 'qweqwe'
AND dNum =1;
--ȯ�Ҹ���Ʈ 
SELECT * FROM REFUND_AND_TOTAL r, stock s
WHERE r.shoesNumber=s.shoesNumber
AND memId = 'jmyoon8'
AND dNum =1;
--ȯ�� /��Ż ���̺�
DROP SEQUENCE rAt_seq;
CREATE SEQUENCE rAt_seq
START WITH 1
INCREMENT BY 1;


---------------------------------------------------------------------------------------
--ȯ�� ���ν���---------------------------------------------------------------------
--���ν����� ȯ���ϰ� ���� ����, ������ ���� ������ �´� ������ ������ �A��. ����ŭ ��Ż�� ī��Ʈ�� - stock�� +
--���� ������ ȯ���ϰ����� ������ ������ 0�Ǹ� ��Ͽ��� ����
SET SERVEROUTPUT ON
CREATE OR REPLACE PROCEDURE refundconfirm(
v_num   in REFUND.REFUNDNUMBER%type,
v_count in REFUND.REFUNDCOUNT%type
)
is
v_snum REFUND.SHOESNUMBER%type;
v_rcount REFUND.REFUNDCOUNT%type;
v_ordernum REFUND.ORDERNUMBER%type;

BEGIN

SELECT shoesnumber into v_snum  FROM refund where REFUNDNUMBER = v_num;
SELECT refundcount into v_rcount FROM refund where REFUNDNUMBER =v_num;
SELECT ordernumber into v_ordernum FROM refund where REFUNDNUMBER =v_num;
       
if(v_count<=v_rcount)then
    
    update refund
    set refundcount = refundcount-v_count
    where REFUNDNUMBER=v_num;
    
    update STOCK
    SET STOCKCOUNT=STOCKCOUNT+v_count
    where shoesnumber = v_snum;
    
    update total
    set ORDERCOUNT =ORDERCOUNT-v_count
    where ORDERNUMBER=v_ordernum;
    
ElSIF(v_count>v_rcount)then
DBMS_OUTPUT.PUT_LINE('������ �ʹ� �����ϴ�.');
end if;

     delete REFUND
     where REFUNDCOUNT=0; 
     delete total
     where ORDERCOUNT=0;
 
end;
/
--Ʈ����---------------------------------------------------
--��������Ʈ�� Ȯ��(����Ʈ)�Ǹ� ����ȯ�� ��Ͽ� �߰�---------
--CREATE OR REPLACE TRIGGER  output_orderlist
--AFTER DELETE ON ORDERLIST FOR EACH ROW
--
--BEGIN
--
--INSERT INTO REFUND
--VALUES(REFUND_NUM.NEXTVAL, :OLD.ORDERNUMBER, :OLD.MEMBERID , :OLD.SHOESNUMBER, :OLD.ORDERCOUNT);
--INSERT INTO total
--VALUES(TOTAL_NUM.NEXTVAL, :OLD.ORDERNUMBER, :OLD.MEMBERID , :OLD.SHOESNUMBER, :OLD.ORDERCOUNT);
--update STOCK
--set STOCKCOUNT=STOCKCOUNT-:old.ordercount
--where shoesnumber=:old.shoesnumber;
--END;
--/
-------------------------------------------------------
















  




